# Οδηγίες για Claude Code — SmartHomePro updates

Άνοιξε το Claude Code μέσα στον φάκελο του τοπικού repo `smarthomepro` (τον ίδιο φάκελο όπου έκανες `git clone`), και δώσε του το εξής μήνυμα:

---

Έχω ένα zip αρχείο `smarthomepro-updates.zip` που περιέχει ενημερωμένα και νέα αρχεία για αυτό
το Astro project. Κάνε τα εξής:

1. Αποσυμπίεσε το zip και αντικατέστησε/πρόσθεσε τα αρχεία στις αντίστοιχες θέσεις μέσα στο `src/`
   (η δομή φακέλων μέσα στο zip είναι ήδη ίδια με το repo: `src/components/...`, `src/layouts/...`,
   `src/pages/...`).

2. Συγκεκριμένα:
   - `src/layouts/Layout.astro` → ΑΝΤΙΚΑΤΑΣΤΗΣΕ το υπάρχον (προσθέτει JSON-LD schema,
     δυναμικό meta description, νέο og:image path)
   - `src/pages/index.astro` → ΑΝΤΙΚΑΤΑΣΤΗΣΕ το υπάρχον (νέο title/description, προσθέτει
     import + χρήση του TechServices component)
   - `src/components/Header.astro` → ΑΝΤΙΚΑΤΑΣΤΗΣΕ το υπάρχον (προσθέτει link "Blog" στο μενού)
   - `src/components/Hero.astro` → ΑΝΤΙΚΑΤΑΣΤΗΣΕ το υπάρχον (προσθέτει TODO σχόλιο για stock photo)
   - `src/components/TechServices.astro` → ΝΕΟ αρχείο, να δημιουργηθεί
   - `src/pages/blog/index.astro` → ΝΕΟ αρχείο (χρειάζεται νέος φάκελος `blog/`), λίστα άρθρων
   - `src/pages/blog/kostos-exypnou-spitiou-knx.astro` → ΝΕΟ αρχείο, πρώτο άρθρο blog

3. Μετά την αντιγραφή, τρέξε `npm run dev` και βεβαιώσου ότι το site φορτώνει χωρίς σφάλματα,
   ότι υπάρχει το section "Ασθενή Συστήματα" στην αρχική, και ότι το `/blog/` δουλεύει.

4. ΣΗΜΑΝΤΙΚΟ: Μέσα στο `src/pages/blog/kostos-exypnou-spitiou-knx.astro` υπάρχει ένα TODO
   σχόλιο με PLACEHOLDER τιμές κόστους — επισήμανέ το σε μένα, χρειάζεται να το συμπληρώσω
   με πραγματικά νούμερα πριν κάνουμε deploy.

5. Αν όλα δουλεύουν σωστά, κάνε:
   git add .
   git commit -m "SEO improvements: schema, blog, ασθενή συστήματα section"
   git push
   (ζήτα μου επιβεβαίωση πριν κάνεις push)

---

## Ακόμα εκκρεμεί (θα το κάνουμε στο επόμενο βήμα)
- Ανέβασμα πραγματικής φωτογραφίας `public/images/og-cover.jpg` (ήδη ετοιμασμένη —
  δες το προηγούμενο μήνυμα στο chat)
- Projects section με τα 5 πραγματικά έργα (Φιλοθέη, Γλυφάδα, Αγ. Δημήτριος, Βύρωνας, Σεπόλια)
- Redirects από bitautomations.gr προς smarthomepro.gr (ΟΧΙ ΑΚΟΜΑ — μετά την ολοκλήρωση περιεχομένου)
